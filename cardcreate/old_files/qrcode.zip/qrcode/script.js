document.addEventListener("DOMContentLoaded", function() {

    var form = document.getElementById('form');

    form.addEventListener('submit', function(e){

    //Capturing datas
    var dateAdhesion = document.getElementById('dateAdhesion').value;
    var dateEnregistrement = document.getElementById('dateEnregistrement').value;
    var departement = document.getElementById('departement').value;
    var commune = document.getElementById('commune').value;
    var arrondissement = document.getElementById('arrondissement').value;
    var village = document.getElementById('village').value;
    var nom = document.getElementById('nom').value;
    var prenom = document.getElementById('prenom').value;
    var udoper = document.getElementById('udoper').value;
    var dateNaissance = document.getElementById('dateNaissance').value;
    var lieuNaissance = document.getElementById('lieuNaissance').value;
    var sexe = document.getElementById('sexe').value;
    var tel = document.getElementById('tel').value;
    var idcard = document.getElementById('idcard').value;
    var numeroPiece = document.getElementById('numeroPiece').value;
    var dateExp = document.getElementById('dateExp').value;
    var photoId = document.getElementById('photoId').value;
    var preview = document.getElementById('preview');
    var form = document.getElementById('form');
    var idcard = document.getElementById('idcard');
        
    e.preventDefault();
    
    });

   
    

    
});